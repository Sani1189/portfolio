"use client"

import * as React from "react"
import { motion } from "framer-motion"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const cardVariants = cva("rounded-lg border bg-card text-card-foreground shadow-sm", {
  variants: {
    variant: {
      default: "bg-card",
      glass: "bg-card/70 backdrop-blur-md border-primary/10",
      gradient: "bg-gradient-to-br from-primary/20 to-secondary/20 border-primary/20",
      outline: "bg-transparent",
    },
  },
  defaultVariants: {
    variant: "default",
  },
})

export interface CustomCardProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof cardVariants> {
  hoverEffect?: boolean
}

export function CustomCard({ className, variant, hoverEffect = false, ...props }: CustomCardProps) {
  return (
    <motion.div
      whileHover={
        hoverEffect
          ? {
              y: -5,
              transition: { duration: 0.2 },
            }
          : undefined
      }
      className={cn(cardVariants({ variant }), className)}
      {...props}
    />
  )
}

export const CustomCardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex flex-col space-y-1.5 p-6", className)} {...props} />
  ),
)
CustomCardHeader.displayName = "CustomCardHeader"

export const CustomCardTitle = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3 ref={ref} className={cn("text-2xl font-semibold leading-none tracking-tight", className)} {...props} />
  ),
)
CustomCardTitle.displayName = "CustomCardTitle"

export const CustomCardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p ref={ref} className={cn("text-sm text-muted-foreground", className)} {...props} />
  ),
)
CustomCardDescription.displayName = "CustomCardDescription"

export const CustomCardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => <div ref={ref} className={cn("p-6 pt-0", className)} {...props} />,
)
CustomCardContent.displayName = "CustomCardContent"

export const CustomCardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("flex items-center p-6 pt-0", className)} {...props} />
  ),
)
CustomCardFooter.displayName = "CustomCardFooter"
